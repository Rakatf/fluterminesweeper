package com.example.minesweeper

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
