class AppRouteName {
  AppRouteName._();

  static String home = "home";
}
